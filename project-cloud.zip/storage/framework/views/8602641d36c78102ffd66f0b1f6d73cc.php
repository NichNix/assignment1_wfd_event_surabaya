<?php $__env->startSection('title', $event->title); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-10">
    <h2 class="text-center text-2xl font-bold mb-6">
        <?php echo e($event->title); ?> || <?php echo e($event->status); ?>

    </h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <!-- Image Section -->
        <div class="rounded shadow overflow-hidden flex justify-center items-center h-80">
            <img
                src="<?php echo e(asset(path: $event->image ?? 'assets/event/default.png')); ?>"
                alt="Event Image"
                class="w-full rounded-lg shadow-md">
        </div>

        <!-- Event Details -->
        <div class="p-4 bg-white shadow rounded-lg">
            <p class="mb-2"><strong>Organizer:</strong> <?php echo e($event->organizer->name); ?></p>
            <p class="mb-2">
                <strong>Date and Time:</strong>
                <?php echo e(\Carbon\Carbon::parse($event->date)->format('F j, Y')); ?>

                at <?php echo e(\Carbon\Carbon::parse($event->start_time)->format('g:i A')); ?>

            </p>
            <p class="mb-2"><strong>Location:</strong> <?php echo e($event->venue); ?></p>

            <!-- Location with Province and Regency -->
            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <p><strong>Province:</strong> <?php echo e($event->province->name ?? 'Not Available'); ?></p>
                </div>
                <div>
                    <p><strong>Kabupaten:</strong> <?php echo e($event->regency->name ?? 'Not Available'); ?></p>
                </div>
            </div>

            <p class="mb-4"><strong>About:</strong> <?php echo e($event->description); ?></p>

            <p class="mb-4">
                <strong>Category:</strong>
                <?php if($event->category): ?>
                <span class="inline-block bg-blue-500 text-white text-sm py-1 px-3 rounded shadow">
                    <?php echo e($event->category->name); ?>

                </span>
                <?php else: ?>
                <span class="text-red-500">No Category</span>
                <?php endif; ?>
            </p>

            <p class="mb-4">
                <strong>Price:</strong>
                <?php if($event->price): ?>
                Rp.<?php echo e(number_format($event->price, 2)); ?>

                <?php else: ?>
                <span class="text-green-500">Free</span>
                <?php endif; ?>
            </p>

            <!-- Ticket Availability -->
            <p class="mb-6">
                <strong>Tickets:</strong>
                <?php echo e($event->sold_tickets); ?> / <?php echo e($event->max_tickets); ?> sold
                <?php if($event->sold_tickets < $event->max_tickets): ?>
                    <span class="text-green-500">(Tickets Available)</span>
                    <?php else: ?>
                    <span class="text-red-500">(Sold Out)</span>
                    <?php endif; ?>
            </p>

            <!-- Booking Button -->
            <?php if($event->status === 'Selesai' || $event->status === 'Sedang berlangsung' || $event->sold_tickets >= $event->max_tickets): ?>
            <button
                class="w-full py-3 px-6 bg-gray-400 text-white font-semibold text-lg rounded-lg cursor-not-allowed opacity-60 hover:bg-gray-500 transition-all duration-300 ease-in-out"
                disabled>
                No Booking Available
            </button>
            <?php else: ?>
            <a
                href="<?php echo e(route('bookings.create', ['event_id' => $event->id])); ?>"
                class="w-full py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-lg rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out transform hover:scale-105">
                Book Now
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\YESTO\laragon\www\assignment1_wfd_event_surabaya\resources\views/events/show.blade.php ENDPATH**/ ?>