

<?php $__env->startSection('title', 'Organizer Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <h2 class="text-3xl font-bold mb-4"><?php echo e($organizer->name); ?></h2>

        <div class="mb-4">
            <p class="font-medium text-gray-700">Facebook:</p>
            <?php if($organizer->facebook_link): ?>
                <a href="<?php echo e($organizer->facebook_link); ?>" target="_blank" class="text-blue-500 hover:underline"><?php echo e($organizer->facebook_link); ?></a>
            <?php else: ?>
                <p class="text-gray-500">N/A</p>
            <?php endif; ?>
        </div>

        <div class="mb-4">
            <p class="font-medium text-gray-700">X (Twitter):</p>
            <?php if($organizer->x_link): ?>
                <a href="<?php echo e($organizer->x_link); ?>" target="_blank" class="text-blue-500 hover:underline"><?php echo e($organizer->x_link); ?></a>
            <?php else: ?>
                <p class="text-gray-500">N/A</p>
            <?php endif; ?>
        </div>

        <div class="mb-4">
            <p class="font-medium text-gray-700">Website:</p>
            <?php if($organizer->website_link): ?>
                <a href="<?php echo e($organizer->website_link); ?>" target="_blank" class="text-blue-500 hover:underline"><?php echo e($organizer->website_link); ?></a>
            <?php else: ?>
                <p class="text-gray-500">N/A</p>
            <?php endif; ?>
        </div>

        <div class="mb-4">
            <p class="font-medium text-gray-700">About the Organizer:</p>
            <p class="text-gray-800"><?php echo e($organizer->description ?? 'N/A'); ?></p>
        </div>

        <a href="<?php echo e(route('organizers.index')); ?>" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded">Back to Organizers</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\YESTO\laragon\www\assignment1_wfd_event_surabaya\resources\views/organizers/show.blade.php ENDPATH**/ ?>