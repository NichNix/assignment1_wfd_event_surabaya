<?php $__env->startSection('title', 'Master Event'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <h2 class="text-2xl font-bold mb-4">Master Event</h2>
        <a href="<?php echo e(route('events.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Create Event</a>

        <div class="mt-6 overflow-x-auto shadow-md rounded-lg">
            <table class="w-full table-auto border-collapse">
                <thead>
                    <tr class="bg-gray-200 text-gray-800">
                        <th class="py-2 px-4 text-left">No</th>
                        <th class="py-2 px-4 text-left">Event Name</th>
                        <th class="py-2 px-4 text-left">Date</th>
                        <th class="py-2 px-4 text-left">Location</th>
                        <th class="py-2 px-4 text-left">Organizer</th>
                        <th class="py-2 px-4 text-left">About</th>
                        <th class="py-2 px-4 text-left">Tags</th>
                        <th class="py-2 px-4 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-100">
                            <td class="py-2 px-4"><?php echo e($loop->iteration); ?></td>
                            <td class="py-2 px-4"><?php echo e($event->title); ?></td>
                            <td class="py-2 px-4"><?php echo e($event->date); ?></td>
                            <td class="py-2 px-4"><?php echo e($event->venue); ?></td>
                            <td class="py-2 px-4"><?php echo e($event->organizer->name ?? 'N/A'); ?></td>
                            <td class="py-2 px-4"><?php echo e(Str::limit($event->description, 50)); ?></td>
                            <td class="py-2 px-4"><?php echo e($event->tags); ?></td>
                            <td class="py-2 px-4">
                                <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-3 rounded">Edit</a>
                                <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded mt-2">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\YESTO\laragon\www\assignment1_wfd_event_surabaya\resources\views/events/masterIndex.blade.php ENDPATH**/ ?>